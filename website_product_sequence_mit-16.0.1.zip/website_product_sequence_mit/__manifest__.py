# -*- coding: utf-8 -*-
{
    'name': "Products Sequence Website",
    'installable': True,
    'application': True,

    'summary': "Adding the functionality of changing the product order in website_sale",

    'description': """
        This module adds product ordering functionality to the webshop. Users can reorder the product columns
        both in Kanban view and List view.
    """,

    'license': 'LGPL-3',
    'category': 'Sales/Sales',
    'version': '16.0.1',

    'depends': ['web', 'website_sale', 'stock'],

    'data': [
        'views/product_sequence.xml',
    ],

    'images': ['static/description/banner.png'],

    # Author
    'author': 'Metzler IT GmbH',
    'support': 'ticket@metzler-it.de',
    'website': 'https://metzler-it.com',
}
