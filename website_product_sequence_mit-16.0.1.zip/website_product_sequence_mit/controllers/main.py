# -*- coding: utf-8 -*-

from odoo import http, fields, models, _
from odoo.http import request
from odoo.addons.web.controllers.dataset import DataSet

class DataSet(DataSet):

    @http.route('/web/dataset/resequence', type='json', auth="user")
    def resequence(self, model, ids, field='sequence', offset=0):
        m = request.env[model]
        if not m.fields_get([field]):
            return False
        # python 2.6 has no start parameter
        if str(m) == 'product.template()':
            field = 'website_sequence'
        for i, record in enumerate(m.browse(ids)):
            record.write({field: i + offset})
        return True

class ProductTemplate(models.Model):
    _inherit = [
        "product.template",
    ]
    website_sequence = fields.Integer('Website Sequence', help="Determine the display order in the Website E-commerce",
                                      default=lambda self: self._default_website_sequence(), copy=False)
    
    def _default_website_sequence(self):
        self._cr.execute("SELECT MAX(website_sequence) FROM %s" % self._table)
        max_sequence = self._cr.fetchone()[0]
        if max_sequence is None:
            return 10000
        return max_sequence + 5